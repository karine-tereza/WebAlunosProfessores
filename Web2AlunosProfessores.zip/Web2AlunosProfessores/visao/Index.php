<html>
	<head>
		<title>Atividade 1 de Web 2</title>
		<meta charset="UTF-8"/>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>		
	</head>
	<body bgcolor="pink">
		<div class="container">
			<?php include("../layout/cabecalho.html") ?>
			<div class="row">
				<?php include("../layout/menu.html") ?>

				<div class="col-md-9">
					<table border="0" width="750" bgcolor="pink" align="center" cellpadding="2" cellpadding="0" bordercolor="yellow"></tr>
					<td>
						<div align="center">
					<h3>Bem vindo ao sistema de cadastro de Alunos e Professores</h3>
					<p><label for="username">Nome: </label> <input type="text" name="nome" size="50" maxlength="250" /> <br/>
					<p><label for="password">Senha: </label> <input type="password" name="senha"  value=" "  id="senha" size="50"/><br/>

					<input type="submit" name="bELogin" value="Login" />

				</div>
			</div>
			<?php include("../layout/rodape.html"); ?>
		</div>	
	</body>
</html>